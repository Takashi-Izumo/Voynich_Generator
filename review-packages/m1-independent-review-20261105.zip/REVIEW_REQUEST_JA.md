# 検証側クラウドへの依頼: M1初期実装の独立検証

添付ZIPのM1実装を、実装側のPASS報告を前提にせず、コードレビューと独立再実行で検証してください。生成品質の改善や正式昇格の承認ではありません。実装ファイル・審判・原版の修正、GitHubへのcommit/push、全200セットの実行は行わず、まず小規模な検証結果と問題点を報告してください。

元仕様書 `ORIGINAL_REQUEST_SPEC_JA.txt` には設計のみという古い制限がありますが、その後ユーザーが明示的に「実装を開始してください」と依頼したため実装されています。元仕様の機構・データ・審判契約を満たしているかを検証してください。

## 1. 検証対象を固定

- Repository: `Takashi-Izumo/Voynich_Generator`
- 基準commit: `c610c2a81e733748e0fb246de89143d6ecda764e`
- 原版: `HerbalA_v22_3_20260921/`
- 追加コード: ZIP内 `payload/experiments/`。この実装はまだGitHubへpushしていません。
- 実装snapshotの各ファイルのSHA-256: `BUNDLE_MANIFEST.json`
- 凍結審判: `judges/v03/`、主判定 `J24.CAL`。

既存チェックアウトがある場合はユーザーの変更を保存し、基準commitからの専用ブランチで確認してください。各クラウドタスクは隔離済みなので、追加のworktreeは不要です。別の実装ブランチや最新mainだけを読んで同じ実装だとみなさないでください。

ZIPは作業用ディレクトリへ展開し、まず同梱 `verify_bundle.py` を読んでから `python verify_bundle.py` で照合してください。`payload/experiments/` を基準チェックアウトへ配置し、配置後に `python verify_bundle.py --installed-root /workspace/Voynich_Generator` で同じファイルが置かれたことを確認します。既存の同名ファイルは確認せず上書きしないでください。

## 2. 依存と原版

セットアップ済みPythonがなければ、原版の `GITHUB_SETUP_JA.md` と `requirements-cloud.txt` を使ってPython 3.12環境を準備してください。2本の親ソースZIPはGit管理外なので、既存の検証済みコピーまたは公開v22.3 Releaseから取得します。TLS・SHA-256検証を省略しないでください。

```text
EHC1_E1GLOBAL_FULL_20260911.zip
cf8ec127ab584a8460c3c02aa4f3a5b2a7f01a328a9b3568f58d6ce0c53c025f
RMW1_BTI2_EHC2_DECOMP1_PUV_HANDOFF_COMPACT_20260912.zip
0a3ea22dbe826ca56100de3e185460e6a3b5e804c5b1166069abfc8dd6c04f29
```

完全版Release:
https://github.com/Takashi-Izumo/Voynich_Generator/releases/tag/HerbalA_v22_3_20260921

## 3. 先にコードレビュー

`experiments/m1_pf/DESIGN.md` と実装を照らし、少なくとも次を確認してください。

1. BASEは原版の2候補argmax＋LEN1救済と同じであるか。
2. PF_NO_RESCUEは救済だけ停止し、PF_ANCHORは2候補を生成・採点しつつ候補0を採るか。
3. BASE救済採用時もRNGは元argmaxから、PF_ANCHORは候補0の終了状態から継続するか。
4. 全segmentのstate/rare/route/段落H1履歴を採用し、非採用枝のpending情報・main RNGが混入しないか。
5. 原版の共有request採番が既存side RNGにも使われる点を特に厳格に評価してください。この実装はBASE再現のため採番を継承しています。D02の仕様適合性と、これによる交絡・総効果の解釈が十分か、追加対比が必要かを独立に判断してください。
6. PLANT切断、BODY再開、複合glyph、可視m、stable/visible、厳密F1LFの二段commitを保っているか。
7. plan/source/data/modelの固定、未完了/改変成果物の拒否、上書き防止、匿名入力と正解の分離が十分か。
8. 原版と審判の採点ロジックが変更されていないか。BASE比較も可能なら凍結runnerの直接実行と照合してください。

問題を見つけたら、コードを直してからPASSにせず、再現コマンド・期待値・実際の挙動・重要度を報告してください。

## 4. 独立した小規模再実行

リポジトリ直下、準備済みPythonで実行します。以下の `/workspace/voynich-results/m1-independent-review` は**未作成の新しい出力先**を使用してください。実装側の保存済み生成結果やPASS報告の再利用ではなく、同じ3葉・seedで新たに生成します。

```bash
export NUMBA_NUM_THREADS=2
export PYTHONPYCACHEPREFIX=/workspace/voynich-results/m1-review-pycache
python -m unittest discover -s experiments/m1_pf/tests -v
python -m unittest discover -s judges/tests -v
python -m experiments.m1_pf plan \
  --output /workspace/voynich-results/m1-independent-review/plan \
  --bifolia A:2,A:3,G:1 --runs 91701
python -m experiments.m1_pf generate \
  --plan /workspace/voynich-results/m1-independent-review/plan/plan.json \
  --output /workspace/voynich-results/m1-independent-review/forward --reference
python -m experiments.m1_pf generate \
  --plan /workspace/voynich-results/m1-independent-review/plan/plan.json \
  --output /workspace/voynich-results/m1-independent-review/reverse --reference \
  --arm-order PF_ANCHOR,PF_NO_RESCUE,BASE
python -m experiments.m1_pf audit \
  --plan /workspace/voynich-results/m1-independent-review/plan/plan.json \
  --generated /workspace/voynich-results/m1-independent-review/forward \
  --repeat /workspace/voynich-results/m1-independent-review/reverse \
  --output /workspace/voynich-results/m1-independent-review/audit
python -m experiments.m1_pf export \
  --plan /workspace/voynich-results/m1-independent-review/plan/plan.json \
  --generated /workspace/voynich-results/m1-independent-review/forward \
  --output /workspace/voynich-results/m1-independent-review/anonymous
```

可能ならforward/reverseを異なるprocessで並行実行し、同じ計画・別出力で結果が一致することも確認してください。

## 5. 固定CALモデルを用いた接続確認

`cal-models/` は元の真正資料と凍結コードから復元し、仕様のmodel-set hashと完全一致したモデルです。別チャットのファイルそのものと同一だという推測ではなく、内容hashで確認してください。

```text
extractor  5b74ed23eda0cad35377e0786f0c3aa8cc7375a033bb6cdc7ed81b98e343bc37
protocol   007d2c9556c5f19a72aa044aa01cf6bf6cbe60f7296e50504112242cf97896f0
model_set  61238cf467871ac13ab9374e2da23ae8a3ad215ea960029e6c8507e065efaf79
```

モデルを再学習・調整したり、PROTOへfallbackしたりせず、ZIP展開先の固定モデルを指定してください。

```bash
python -m experiments.m1_pf evaluate \
  --plan /workspace/voynich-results/m1-independent-review/plan/plan.json \
  --inputs /workspace/voynich-results/m1-independent-review/anonymous \
  --models /ZIPの展開先/cal-models \
  --output /workspace/voynich-results/m1-independent-review/evaluation \
  --jobs 2 --bootstrap 100
```

これは3葉・1seedの接続smokeです。100反復の区間から改善・有意性を主張しないでください。未実施の能力確認、一般化、全20葉×10seed比較、採否の閾値を実施済みと扱わないでください。

## 6. 報告形式

- 検証環境、基準commit、実装snapshot hash、実行したコマンド。
- PASS / FAIL / 未実施を分け、テスト実行数と実生成数を記載。
- BASE一致、枝の隔離、state/RNG継続、採番とside RNG、mask/匿名化、固定モデルについて独立した結論。
- 問題があれば重要度・ファイル/関数・再現手順・修正案。実装側の自己申告を引用しただけならそう明記。
- 最終的に「このM1を本比較へ進めてよいか」を、保留条件付きでも回答。機構PASSと生成品質改善・正式昇格を分ける。
