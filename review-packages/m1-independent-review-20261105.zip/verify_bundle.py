"""Read-only verification of the review bundle and optionally installed payload."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath


def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--installed-root', type=Path)
    args = ap.parse_args()
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'BUNDLE_MANIFEST.json').read_text())
    checked = installed = 0
    for row in manifest['files']:
        name = PurePosixPath(row['path'])
        if name.is_absolute() or '..' in name.parts:
            raise ValueError('Invalid manifest path')
        p = root.joinpath(*name.parts)
        if p.stat().st_size != row['bytes'] or sha(p) != row['sha256']:
            raise ValueError('Bundle file mismatch: ' + row['path'])
        checked += 1
        if args.installed_root and name.parts[0] == 'payload':
            target = args.installed_root.joinpath(*name.parts[1:])
            if not target.is_file() or sha(target) != row['sha256']:
                raise ValueError('Installed payload differs: ' + str(target))
            installed += 1
    model = json.loads((root / 'cal-models/models.json').read_text())
    digest = hashlib.sha256(json.dumps(model, ensure_ascii=False, sort_keys=True,
                           separators=(',', ':'), allow_nan=False).encode()).hexdigest()
    if digest != manifest['required_model_set_hash']:
        raise ValueError('Frozen CAL model-set hash differs')
    print(json.dumps({'status': 'PASS', 'bundle_files_checked': checked,
                      'installed_payload_files_checked': installed,
                      'base_commit': manifest['base_commit'], 'model_set_hash': digest}, indent=2))


if __name__ == '__main__':
    main()
